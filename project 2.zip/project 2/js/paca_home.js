function startTime() {
    var today = new Date();

    var h = today.getHours();
    var m = today.getMinutes();
    var s = today.getSeconds();
    m = checkTime(m);
    s = checkTime(s);
    document.getElementById('time').innerHTML =today + ""
    h + ":" + m + ":" + s;
    var t = setTimeout(startTime, 500);
}
function checkTime(i) {
    if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
    return i;
}
function order() {


var  x=document.getElementById("sort").value;

  if(x==="Ascending"||x==="All") {
      document.getElementById("order_1").style.display ="inline-block";
      document.getElementById("order_2").style.display ="none";
  }





    if(x==="Descending") {
        document.getElementById("order_1").style.display = "none";
        document.getElementById("order_2").style.display = "inline-block";

    }



}